//
// Created by Devin Plauche on 1/28/20.
//
#include "Param.h"
string Param::toString() {
    return paramValue;
}