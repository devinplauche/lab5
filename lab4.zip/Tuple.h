//
// Created by Devin Plauche on 3/15/20.
//

#ifndef LAB3_TUPLE_H
#define LAB3_TUPLE_H

#include <string>
#include<vector>
using namespace std;

class Tuple :public vector<string> {
public:
    //vector<string> values;
};


#endif //LAB3_TUPLE_H
