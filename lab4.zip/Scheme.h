//
// Created by Devin Plauche on 3/15/20.
//

#ifndef LAB3_SCHEME_H
#define LAB3_SCHEME_H
#include<string>
#include<vector>
#include<set>
#include"Tuple.h"
using namespace std;

class Scheme {
public:
    Scheme() {

    }

    vector<string> attributes;
};


#endif //LAB3_SCHEME_H
